VSR DDS VIEWER — PROYECTO ANDROID

Este proyecto genera la APK mediante GitHub Actions. No necesitas Android Studio.

PASOS
1. En GitHub, crea un repositorio NUEVO llamado VSR-DDS-Viewer. Puede ser público o privado.
2. En el repositorio, pulsa Add file > Upload files.
3. Descomprime este ZIP. Entra en VSR_DDS_Viewer y arrastra TODO su contenido (incluida la carpeta oculta .github) a GitHub. No subas la carpeta exterior como una única carpeta.
4. Pulsa Commit changes.
5. Abre Actions y acepta habilitar workflows si GitHub lo solicita.
6. Abre Build Android APK y pulsa Run workflow > Run workflow.
7. Cuando termine en verde, abre la ejecución y descarga el artefacto VSR-DDS-Viewer-APK.
8. Descomprime el artefacto: dentro estará app-debug.apk. Pásalo al móvil e instálalo.

Si no aparece el workflow, comprueba que exista .github/workflows/build-apk.yml en la raíz del repositorio.

Funciones previstas: abrir DDS, zoom y desplazamiento, mostrar resolución/formato/mipmaps y exportar PNG. La compatibilidad depende de los formatos admitidos por image_dds.

La APK todavía no está compilada ni probada; GitHub Actions realizará la compilación.
