use jni::objects::{JByteArray, JClass};
use jni::sys::jbyteArray;
use jni::JNIEnv;
use std::io::Cursor;

#[no_mangle]
pub extern "system" fn Java_com_vsr_ddsviewer_NativeDds_decodeDds(
    mut env: JNIEnv,
    _class: JClass,
    input: JByteArray,
) -> jbyteArray {
    let result = (|| -> Result<Vec<u8>, String> {
        let bytes = env.convert_byte_array(&input).map_err(|e| e.to_string())?;
        let mut cursor = Cursor::new(bytes);
        let dds = image_dds::ddsfile::Dds::read(&mut cursor).map_err(|e| format!("DDS inválido: {e}"))?;
        let rgba = image_dds::image_from_dds(&dds, 0).map_err(|e| format!("Formato DDS no compatible: {e}"))?;
        let image = image_dds::image::DynamicImage::ImageRgba8(rgba);
        let mut output = Cursor::new(Vec::new());
        image.write_to(&mut output, image_dds::image::ImageFormat::Png)
            .map_err(|e| format!("Error convirtiendo a PNG: {e}"))?;
        Ok(output.into_inner())
    })();

    match result {
        Ok(png) => env.byte_array_from_slice(&png).map(|array| array.into_raw()).unwrap_or(std::ptr::null_mut()),
        Err(message) => {
            let _ = env.throw_new("java/lang/IllegalArgumentException", message);
            std::ptr::null_mut()
        }
    }
}
