package com.vsr.ddsviewer

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var preview: ZoomImageView
    private lateinit var info: TextView
    private var pngBytes: ByteArray? = null
    private var currentName = "textura.png"

    private val openFile = registerForActivityResultCompat(OPEN_REQUEST) { uri ->
        if (uri != null) loadDds(uri)
    }
    private val saveFile = registerForActivityResultCompat(SAVE_REQUEST) { uri ->
        if (uri != null) savePng(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(12))
            setBackgroundColor(0xFF101318.toInt())
        }
        val title = TextView(this).apply {
            text = "VSR DDS VIEWER"
            textSize = 22f
            setTextColor(0xFFF3F5FA.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Visor de texturas para Farming Simulator"
            textSize = 13f
            setTextColor(0xFF9CA6B5.toInt())
            setPadding(0, dp(4), 0, dp(14))
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val open = makeButton("ABRIR DDS") { openFile.launch(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }) }
        val save = makeButton("GUARDAR PNG") {
            if (pngBytes == null) toast("Primero abre un archivo DDS")
            else saveFile.launch(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "image/png"
                putExtra(Intent.EXTRA_TITLE, currentName.substringBeforeLast('.', currentName) + ".png")
            })
        }
        buttons.addView(open, LinearLayout.LayoutParams(0, dp(48), 1f))
        buttons.addView(save, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(8) })
        preview = ZoomImageView(this).apply {
            setBackgroundColor(0xFF080A0E.toInt())
            setImageDrawable(null)
            contentDescription = "Vista previa de textura DDS. Usa dos dedos para ampliar."
        }
        info = TextView(this).apply {
            text = "Abre un archivo .DDS para visualizarlo.\n\nAdmite DDS comprimidos BC1/DXT1, BC2/DXT3, BC3/DXT5, BC4, BC5, BC7 y formatos compatibles."
            textSize = 13f
            setTextColor(0xFFD6DCE7.toInt())
            setPadding(dp(4), dp(14), dp(4), dp(8))
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(buttons)
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(14); bottomMargin = dp(8) })
        root.addView(info)
        setContentView(root)
    }

    private fun loadDds(uri: Uri) {
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalStateException("No se pudo leer el archivo")
                if (bytes.size < 128 || bytes[0] != 0x44.toByte() || bytes[1] != 0x44.toByte() ||
                    bytes[2] != 0x53.toByte() || bytes[3] != 0x20.toByte()) {
                    throw IllegalArgumentException("El archivo seleccionado no parece ser un DDS válido.")
                }
                val width = leInt(bytes, 16)
                val height = leInt(bytes, 12)
                val mipmaps = leInt(bytes, 28).coerceAtLeast(1)
                val fourCC = String(bytes.copyOfRange(84, 88), Charsets.US_ASCII).trim('\u0000', ' ')
                val format = when (fourCC) {
                    "DXT1" -> "BC1 / DXT1"
                    "DXT3", "DXT2" -> "BC2 / DXT3"
                    "DXT5", "DXT4" -> "BC3 / DXT5"
                    "ATI1", "BC4U" -> "BC4"
                    "ATI2", "BC5U" -> "BC5"
                    "DX10" -> "DX10 (DXGI ${if (bytes.size >= 132) leInt(bytes, 128) else "?"})"
                    else -> if (fourCC.isBlank()) "Sin FourCC / formato RGB" else fourCC
                }
                val decoded = NativeDds.decodeDds(bytes)
                val bitmap = BitmapFactory.decodeByteArray(decoded, 0, decoded.size)
                    ?: throw IllegalStateException("No se pudo crear la imagen")
                runOnUiThread {
                    preview.setImageBitmap(bitmap)
                    preview.post { preview.resetZoom() }
                    pngBytes = decoded
                    currentName = uri.lastPathSegment?.substringAfterLast('/') ?: "textura.dds"
                    info.text = "Archivo: $currentName\nResolución: ${width} × ${height}\nFormato: $format\nMipmaps: $mipmaps\n\nZoom: pellizca con dos dedos. Arrastra para moverte."
                }
            } catch (e: Exception) {
                runOnUiThread { toast(e.message ?: "Error al abrir DDS") }
            }
        }.start()
    }

    private fun savePng(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(pngBytes!!) }
            toast("PNG guardado correctamente")
        } catch (e: Exception) { toast("No se pudo guardar: ${e.message}") }
    }

    private fun leInt(b: ByteArray, offset: Int): Int {
        if (offset + 4 > b.size) return 0
        return (b[offset].toInt() and 255) or
            ((b[offset + 1].toInt() and 255) shl 8) or
            ((b[offset + 2].toInt() and 255) shl 16) or
            ((b[offset + 3].toInt() and 255) shl 24)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF344A83.toInt()))
        setOnClickListener { action() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    companion object {
        private const val OPEN_REQUEST = 1001
        private const val SAVE_REQUEST = 1002
    }

    // Small compatibility wrapper around the Activity Result API.
    private fun registerForActivityResultCompat(
        request: Int,
        callback: (Uri?) -> Unit
    ): LegacyPicker {
        return LegacyPicker(this, request, callback)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            OPEN_REQUEST -> if (resultCode == RESULT_OK) openCallback?.invoke(data?.data)
            SAVE_REQUEST -> if (resultCode == RESULT_OK) saveCallback?.invoke(data?.data)
        }
    }

    private var openCallback: ((Uri?) -> Unit)? = null
    private var saveCallback: ((Uri?) -> Unit)? = null

    private inner class LegacyPicker(
        private val activity: Activity,
        private val request: Int,
        private val callback: (Uri?) -> Unit
    ) {
        fun launch(intent: Intent) {
            if (request == OPEN_REQUEST) openCallback = callback else saveCallback = callback
            activity.startActivityForResult(intent, request)
        }
    }
}
