package com.vsr.ddsviewer

internal object NativeDds {
    init { System.loadLibrary("ddsdecoder") }
    external fun decodeDds(bytes: ByteArray): ByteArray
}
