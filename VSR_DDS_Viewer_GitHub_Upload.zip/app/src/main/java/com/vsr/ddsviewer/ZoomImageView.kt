package com.vsr.ddsviewer

import android.content.Context
import android.graphics.Matrix
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.ImageView
import kotlin.math.max
import kotlin.math.min

class ZoomImageView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : ImageView(context, attrs) {
    private val imageMatrixValue = Matrix()
    private var scale = 1f
    private var lastX = 0f
    private var lastY = 0f
    private val detector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val next = (scale * detector.scaleFactor).coerceIn(0.5f, 8f)
            val factor = next / scale
            imageMatrixValue.postScale(factor, factor, detector.focusX, detector.focusY)
            scale = next
            imageMatrix = imageMatrixValue
            return true
        }
    })

    init { scaleType = ScaleType.MATRIX; imageMatrix = imageMatrixValue }

    fun resetZoom() {
        scale = 1f
        imageMatrixValue.reset()
        val d = drawable ?: return
        val vw = width.toFloat().coerceAtLeast(1f)
        val vh = height.toFloat().coerceAtLeast(1f)
        val fit = min(vw / d.intrinsicWidth.coerceAtLeast(1), vh / d.intrinsicHeight.coerceAtLeast(1))
        val dx = (vw - d.intrinsicWidth * fit) / 2f
        val dy = (vh - d.intrinsicHeight * fit) / 2f
        imageMatrixValue.setScale(fit, fit)
        imageMatrixValue.postTranslate(dx, dy)
        imageMatrix = imageMatrixValue
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        post { resetZoom() }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        detector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = event.x; lastY = event.y; return true }
            MotionEvent.ACTION_MOVE -> if (!detector.isInProgress && event.pointerCount == 1) {
                val dx = event.x - lastX
                val dy = event.y - lastY
                imageMatrixValue.postTranslate(dx, dy)
                imageMatrix = imageMatrixValue
                lastX = event.x; lastY = event.y
            }
        }
        return true
    }
}
