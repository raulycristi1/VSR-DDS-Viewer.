plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.vsr.ddsviewer"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.vsr.ddsviewer"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }
    sourceSets["main"].jniLibs.srcDirs("src/main/jniLibs")
}
